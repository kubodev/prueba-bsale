# prueba-bsale
Es una api en un base de datos de pruebas en mysql y un html, con boostrap y vanilla javascript.
